class MyCustomCalculator:
    def __init__(self):
        self.operators = {'+': 1, '*': 0}

    def to_postfix(self, expression):
        stack = []
        postfix = []
        
        for char in expression.split():
            if char.isdigit():
                postfix.append(char)
            elif char == '(':
                stack.append(char)
            elif char == ')':
                while stack and stack[-1] != '(':
                    postfix.append(stack.pop())
                stack.pop()  # Discard the '('
            else:
                while stack and self.operators.get(stack[-1], 0) >= self.operators.get(char, 0):
                    postfix.append(stack.pop())
                stack.append(char)
        
        while stack:
            postfix.append(stack.pop())
        
        return postfix
    
    def evaluate(self, postfix):
        stack = []
        
        for char in postfix:
            if char.isdigit():
                stack.append(int(char))
            else:
                b = stack.pop()
                a = stack.pop()
                if char == '+':
                    stack.append(a + b)
                elif char == '*':
                    stack.append(a * b)
        
        return stack[0]
    
    def to_prefix(self, expression):
        reversed_expression = expression[::-1]
        reversed_postfix = self.to_postfix(reversed_expression)
        prefix = reversed_postfix[::-1]
        return prefix
    
def main():
    calculator = MyCustomCalculator()
    expression = input("Enter arithmetic expression in infix notation (2 + 1 * 3): ")
    prefix_expression = calculator.to_prefix(expression)
    postfix_expression = calculator.to_postfix(expression)
    result = calculator.evaluate(postfix_expression)
    
    print("The Calculation's result:", result)
    print("Prefix Expression Result:", prefix_expression)
    print("Postfix Expression Result:", postfix_expression)

if __name__ == "__main__":
    main()
